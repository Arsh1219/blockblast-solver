# 🧱 Block Blast Solver

Upload a screenshot of a Block Blast board (8×8 grid + 3 pieces below) and get a step-by-step solution that maximises line clears.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

The app opens at `http://localhost:8501`.

## Deploy to Streamlit Community Cloud (free, public URL)

1. Create a new public GitHub repo and push these files:
   - `app.py`
   - `solver.py`
   - `requirements.txt`
   - `README.md`
2. Go to <https://share.streamlit.io> and sign in with GitHub.
3. Click **New app**, select your repo, and set the main file to `app.py`.
4. Click **Deploy**. You get a public URL like `https://<you>-blockblast-solver.streamlit.app`.

Pushes to `main` redeploy automatically.

## Alternative: Hugging Face Spaces (also free)

1. Create a new Space → SDK = **Streamlit**.
2. Upload the same four files.
3. Done. Public URL provided.

## How it works

- `solver.detect_grid_bounds` — finds the playing grid by masking the dark blue background and orange bricks.
- `solver.read_grid_state` — samples each cell centre to determine filled vs empty.
- `solver.detect_pieces` — finds the three piece bounding boxes below the board, infers a common cell size, and reads each piece's shape.
- `solver.solve` — brute-force search over all piece orderings and placements, with line-clear mechanics applied between placements. Returns the placement that clears the most lines.
- `solver.render_solution` — produces an annotated step-by-step PNG.

## Limits / notes

- Pieces are not rotated (matches the standard Block Blast UX).
- Grid size defaults to 8×8; sidebar lets you switch to 9 or 10.
- Detection assumes the standard Block Blast colour palette (dark blue grid, orange bricks). Heavy theme changes may need threshold tuning in `solver.brick_mask` / `solver.grid_bg_mask`.
